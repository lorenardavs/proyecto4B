$(document).ready(function(){
  $("[data-toggle='tooltip']").tooltip();
  $("[data-toggle='popover']").popover();
  $('.carousel').carousel({
      interval: 2000
  });

  $("#myBtn").click(function(){
    $("#myModal").modal("show");
      $('#myBtn').prop('disabled', true);
  });
  $("#btnclose").click(function(){
    $("#myModal").modal("hide");
    $('#myBtn').prop('disabled', false);
  });
  $("#myModal").on('show.bs.modal', function () {
    alert('El modal se va a mostrar');
    console.log("%cEl modal se va a mostrar", "color: green; font-family:'Comic Sans MS'");
  });
  $("#myModal").on('shown.bs.modal', function () {
    alert('El modal se mostró');
    console.log("%cEl modal se mostró", "color: green; font-family:'Comic Sans MS'");
    $('#myBtn').removeClass('btn-primary');
    $('#myBtn').addClass('btn-success');
  });
  $("#myModal").on('hide.bs.modal', function () {
    alert('El modal se va a cerrar');
    console.log("%cEl modal se va a cerrar", "color: green; font-family:'Comic Sans MS'");

  });
  $("#myModal").on('hidden.bs.modal', function () {
    alert('El modal se cerró');
    console.log("%cEl modal se cerró", "color: green; font-family:'Comic Sans MS'");
    $('#myBtn').removeClass('btn-success');
    $('#myBtn').addClass('btn-primary');
  });
});
